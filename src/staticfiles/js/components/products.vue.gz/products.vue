<template>
    
</template>

<script>
export default {
    name: 'products',
    mounted: function(){
        // get all products of currently selected section
    }
}
</script>

<style scoped>

</style>